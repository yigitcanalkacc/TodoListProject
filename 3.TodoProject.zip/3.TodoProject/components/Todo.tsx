
import React, { useState } from 'react'
import { CiCircleRemove } from "react-icons/ci";
import { FaRegEdit } from "react-icons/fa";
import { TodoTypes } from '../types/types';
import { useDispatch } from 'react-redux'
import { removeTodo, updateTodo } from '../redux/TodoSlice';
import { FaCheck } from "react-icons/fa6";




interface todoProps {
    todoProps: TodoTypes
}



function Todo({ todoProps }: todoProps) {
    const { id, content } = todoProps
    const [editable, setEditable] = useState<boolean>(false);
    const [newTodo, setNewTodo] = useState(content);
    const dispatch = useDispatch();


    const handeRemoveTodo = () => {
        dispatch(removeTodo(id))
    }

    const editFunction = () => {
        setEditable(!editable);
    }

    const handleUpdateTodo = () => {

        const payload: TodoTypes = {
            id: id,
            content: newTodo
        }

        dispatch(updateTodo(payload))
        setEditable(false);
        setNewTodo('');
    }


    return (


        <div className='todo-content'>

            {
                editable ? <input type="text" className='input-box-true'
                    value={newTodo}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTodo(e.target.value)}
                /> : <div>{content}</div>
            }

            <div className='todo-icons-div'>
                <div>

                    {
                        editable ? <FaCheck className='icons' onClick={handleUpdateTodo} /> : <FaRegEdit onClick={editFunction} className='icons' />
                    }


                    <CiCircleRemove
                        onClick={handeRemoveTodo}
                        className='icons' />
                </div>



            </div>
        </div>
    )
}

export default Todo
