import React from 'react'
import Todo from './Todo'
import { useSelector } from 'react-redux'
import { RootState } from '../redux/store';
import { TodoTypes } from '../types/types';
import { TodoSlice } from '../redux/TodoSlice';

function TodoList() {
    const { todos } = useSelector((state: RootState) => state.todoslice);
    return (
        <div>
            {
                todos && todos.map((todo: TodoTypes) => (
                    <Todo key={todo.id} todoProps={todo} />
                ))
            }

        </div>
    )
}

export default TodoList
