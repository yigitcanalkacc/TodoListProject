import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { createTodo } from '../redux/TodoSlice';
import { TodoTypes } from '../types/types';

function TodoComp() {

    const dispatch = useDispatch();
    const [newTodo, SetnewTodo] = useState('');

    const handleCreateTodo = () => {

        if (newTodo.trim().length == 0) {
            alert("Todo Giriniz")
            return
        }

        const payload: TodoTypes = {
            id: Math.floor(Math.random() * 9999999),
            content: newTodo
        }

        dispatch(createTodo(payload))
        SetnewTodo('')
    }

    return (
        <div className='todo-div'>
            <input
                value={newTodo}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => SetnewTodo(e.target.value)}
                className='todo-input' type="text" placeholder='Lütfen bir şey ekleyiniz.' />

            <div>
                <button className='todo-button' onClick={handleCreateTodo}>Ekle</button>
            </div>
        </div>

    )
}

export default TodoComp
