export interface TodoInitialState {
    todos: TodoTypes[]
}


export interface TodoTypes {
    id: number,
    content: string
}