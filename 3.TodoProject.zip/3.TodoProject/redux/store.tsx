import { configureStore } from '@reduxjs/toolkit'
import todoReducers from './TodoSlice'

export const store = configureStore({
    reducer: {
        todoslice: todoReducers
    },
});

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch