import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import { TodoInitialState, TodoTypes } from '../types/types'

const initialState: TodoInitialState = {
    todos: []
}

export const TodoSlice = createSlice({
    name: 'todoslicer',
    initialState,
    reducers: {
        createTodo: (state: TodoInitialState, action: PayloadAction<TodoTypes>) => {
            state.todos = [...state.todos, action.payload]
        },

        removeTodo: (state: TodoInitialState, action: PayloadAction<number>) => {
            state.todos = [...state.todos.filter((todo: TodoTypes) => todo.id !== action.payload)]
        },

        updateTodo: (state: TodoInitialState, action: PayloadAction<TodoTypes>) => {
            state.todos = [...state.todos.map((todo: TodoTypes) => todo.id !== action.payload.id ? todo : action.payload)]
        }
    },
})

export const { createTodo, removeTodo, updateTodo } = TodoSlice.actions
export default TodoSlice.reducer