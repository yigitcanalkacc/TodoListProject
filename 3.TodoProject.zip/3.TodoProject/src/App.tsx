import { useState } from 'react'
import TodoComp from '../components/TodoComp'
import TodoList from '../components/TodoList'




import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <TodoComp />
      <TodoList />
    </>
  )
}

export default App
